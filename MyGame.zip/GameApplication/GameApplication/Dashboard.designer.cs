﻿
namespace GameApplication
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_eight_queen_puzzle = new System.Windows.Forms.Button();
            this.btn_encode_decode = new System.Windows.Forms.Button();
            this.btn_tic_tac_toe = new System.Windows.Forms.Button();
            this.btn_shortest_path = new System.Windows.Forms.Button();
            this.btn_minimum_connectors = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_eight_queen_puzzle
            // 
            this.btn_eight_queen_puzzle.Location = new System.Drawing.Point(106, 30);
            this.btn_eight_queen_puzzle.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_eight_queen_puzzle.Name = "btn_eight_queen_puzzle";
            this.btn_eight_queen_puzzle.Size = new System.Drawing.Size(244, 171);
            this.btn_eight_queen_puzzle.TabIndex = 0;
            this.btn_eight_queen_puzzle.Text = "Eight queens’ puzzle";
            this.btn_eight_queen_puzzle.UseVisualStyleBackColor = true;
            this.btn_eight_queen_puzzle.Click += new System.EventHandler(this.btn_eight_queen_puzzle_Click);
            // 
            // btn_encode_decode
            // 
            this.btn_encode_decode.Location = new System.Drawing.Point(567, 30);
            this.btn_encode_decode.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_encode_decode.Name = "btn_encode_decode";
            this.btn_encode_decode.Size = new System.Drawing.Size(244, 171);
            this.btn_encode_decode.TabIndex = 1;
            this.btn_encode_decode.Text = "Encode /Decode";
            this.btn_encode_decode.UseVisualStyleBackColor = true;
            this.btn_encode_decode.Click += new System.EventHandler(this.btn_encode_decode_Click);
            // 
            // btn_tic_tac_toe
            // 
            this.btn_tic_tac_toe.Location = new System.Drawing.Point(64, 343);
            this.btn_tic_tac_toe.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_tic_tac_toe.Name = "btn_tic_tac_toe";
            this.btn_tic_tac_toe.Size = new System.Drawing.Size(244, 171);
            this.btn_tic_tac_toe.TabIndex = 2;
            this.btn_tic_tac_toe.Text = " Tic-Tac-Toe";
            this.btn_tic_tac_toe.UseVisualStyleBackColor = true;
            this.btn_tic_tac_toe.Click += new System.EventHandler(this.btn_tic_tac_toe_Click);
            // 
            // btn_shortest_path
            // 
            this.btn_shortest_path.Location = new System.Drawing.Point(651, 330);
            this.btn_shortest_path.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_shortest_path.Name = "btn_shortest_path";
            this.btn_shortest_path.Size = new System.Drawing.Size(244, 171);
            this.btn_shortest_path.TabIndex = 3;
            this.btn_shortest_path.Text = " Shortest Path";
            this.btn_shortest_path.UseVisualStyleBackColor = true;
            this.btn_shortest_path.Click += new System.EventHandler(this.btn_shortest_path_Click);
            // 
            // btn_minimum_connectors
            // 
            this.btn_minimum_connectors.Location = new System.Drawing.Point(348, 252);
            this.btn_minimum_connectors.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_minimum_connectors.Name = "btn_minimum_connectors";
            this.btn_minimum_connectors.Size = new System.Drawing.Size(244, 171);
            this.btn_minimum_connectors.TabIndex = 4;
            this.btn_minimum_connectors.Text = "Minimum Connectors";
            this.btn_minimum_connectors.UseVisualStyleBackColor = true;
            this.btn_minimum_connectors.Click += new System.EventHandler(this.btn_minimum_connectors_Click);
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(932, 609);
            this.Controls.Add(this.btn_minimum_connectors);
            this.Controls.Add(this.btn_shortest_path);
            this.Controls.Add(this.btn_tic_tac_toe);
            this.Controls.Add(this.btn_encode_decode);
            this.Controls.Add(this.btn_eight_queen_puzzle);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Dashboard";
            this.Text = "Dashboard";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_eight_queen_puzzle;
        private System.Windows.Forms.Button btn_encode_decode;
        private System.Windows.Forms.Button btn_tic_tac_toe;
        private System.Windows.Forms.Button btn_shortest_path;
        private System.Windows.Forms.Button btn_minimum_connectors;
    }
}