﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace GameApplication
{
    public partial class MainForm2 : Form
    {
        private char currentPlayer;
        private char[,] board;
        private Button[,] buttons;
        private Random random;
        public static string user;

        public MainForm2()
        {
            InitializeComponent();
            InitializeBoard();
            user = MainForm.SetValueForText2;
            label2.Text = user;
            random = new Random();
            con = new SqlConnection("Data Source=LAPTOP-ATG56U89;Initial Catalog=GameApp;Integrated Security=True");
        }
        SqlConnection con;
        SqlCommand cmd;
        private void InitializeBoard()
        {
            currentPlayer = 'X';
            board = new char[3, 3];
            buttons = new Button[3, 3]
            {
                { button1, button2, button3 },
                { button4, button5, button6 },
                { button7, button8, button9 }
            };

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    buttons[i, j].Text = "";
                    buttons[i, j].Enabled = true;
                    buttons[i, j].Tag = i * 3 + j;
                    buttons[i, j].Click += Button1_Click;
                    board[i, j] = '\0';
                }
            }

        }

        private void Button1_Click(object sender, EventArgs e)
        {
          
        }
        private void MakeComputerMove()
        {
            // Find all available empty buttons
            var availableButtons = new List<Button>();
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (board[i, j] == '\0')
                        availableButtons.Add(buttons[i, j]);
                }
            }

            if (availableButtons.Count > 0)
            {
                // Select a random button and make the computer move
                int randomIndex = random.Next(availableButtons.Count);
                Button randomButton = availableButtons[randomIndex];

                int row = (int)randomButton.Tag / 3;
                int col = (int)randomButton.Tag % 3;

                board[row, col] = currentPlayer;
                randomButton.Text = currentPlayer.ToString();
                randomButton.Enabled = false;

                if (CheckWin(currentPlayer))
                {
                    MessageBox.Show(this,$"Player {currentPlayer} wins!","Information",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    String status, playerName;

                    status = "lost";

                    playerName = user;


                    try
                    {
                        con.Open();
                        cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                        cmd.Parameters.AddWithValue("b", status);
                        cmd.Parameters.AddWithValue("c", playerName);




                        int i = cmd.ExecuteNonQuery();

                        if (i == 1)
                            MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        con.Close();
                        cmd.Dispose();
                    }
                    catch (SqlException ex)
                    {

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    InitializeBoard();
                    return;
                }

                if (CheckDraw())
                {
                    MessageBox.Show(this,"It's a draw!","Information",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    String status, playerName;

                    status = "draw";

                    playerName = user;


                    try
                    {
                        con.Open();
                        cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                        cmd.Parameters.AddWithValue("b", status);
                        cmd.Parameters.AddWithValue("c", playerName);




                        int i = cmd.ExecuteNonQuery();

                        if (i == 1)
                            MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        con.Close();
                        cmd.Dispose();
                    }
                    catch (SqlException ex)
                    {

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    InitializeBoard();
                    return;
                }

                currentPlayer = 'X';
            }
        }

        private bool CheckWin(char player)
        {

            // Check rows
            for (int i = 0; i < 3; i++)
            {
                if (board[i, 0] == player && board[i, 1] == player && board[i, 2] == player)
                    return true;
            }

            // Check columns
            for (int i = 0; i < 3; i++)
            {
                if (board[0, i] == player && board[1, i] == player && board[2, i] == player)
                    return true;
            }

            // Check diagonals
            if ((board[0, 0] == player && board[1, 1] == player && board[2, 2] == player) ||
                (board[2, 0] == player && board[1, 1] == player && board[0, 2] == player))
            {
                return true;
            }

            return false;

        }

        private bool CheckDraw()
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (board[i, j] == '\0')
                        return false;
                }
            }

            return true;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

            Button button = (Button)sender;

            int row = (int)button.Tag / 3;
            int col = (int)button.Tag % 3;

            if (board[row, col] != '\0')
                return;

            board[row, col] = currentPlayer;
            button.Text = currentPlayer.ToString();
            button.Enabled = false;

            if (CheckWin(currentPlayer))
            {
                MessageBox.Show(this,$"Player {currentPlayer} wins!","Information",MessageBoxButtons.OK,MessageBoxIcon.Information);
               
                String status,playerName;
               
                    status = "win";
                
                playerName = user;
                

              try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {

                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                InitializeBoard();
                return;
            }

            if (CheckDraw())
            {
                MessageBox.Show("It's a draw!","Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);

                String status, playerName;
                playerName = user;
                status = "draw";


                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values (@b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {

                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                InitializeBoard();
                return;
            }

            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';

            if (currentPlayer == 'O')
                MakeComputerMove();

        }

        private void button2_Click(object sender, EventArgs e)
        {

            Button button = (Button)sender;

            int row = (int)button.Tag / 3;
            int col = (int)button.Tag % 3;

            if (board[row, col] != '\0')
                return;

            board[row, col] = currentPlayer;
            button.Text = currentPlayer.ToString();
            button.Enabled = false;

            if (CheckWin(currentPlayer))
            {
                MessageBox.Show(this, $"Player {currentPlayer} wins!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                String status, playerName;
                
                    status = "win";
               
                playerName = user;


                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {

                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                InitializeBoard();
                return;
            }

            if (CheckDraw())
            {
                MessageBox.Show("It's a draw!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);

                String status, playerName;
                playerName = user;
                status = "draw";


                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values (@b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
               }
                catch (SqlException ex)
                {

                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                InitializeBoard();
                return;
            }

            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';

            if (currentPlayer == 'O')
                MakeComputerMove();


        }

        private void button3_Click(object sender, EventArgs e)
        {

            Button button = (Button)sender;

            int row = (int)button.Tag / 3;
            int col = (int)button.Tag % 3;

            if (board[row, col] != '\0')
                return;

            board[row, col] = currentPlayer;
            button.Text = currentPlayer.ToString();
            button.Enabled = false;
            if (CheckWin(currentPlayer))
            {
                MessageBox.Show(this, $"Player {currentPlayer} wins!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                String status, playerName;
                
                    status = "win";
               
                playerName = user;


                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {

                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                InitializeBoard();
                return;
            }

            if (CheckDraw())
            {
                MessageBox.Show("It's a draw!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);

                String status, playerName;
                playerName = user;
                status = "draw";


                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values (@b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {

                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                InitializeBoard();
                return;
            }

            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';

            if (currentPlayer == 'O')
                MakeComputerMove();



        }

        private void button4_Click(object sender, EventArgs e)
        {


            Button button = (Button)sender;

            int row = (int)button.Tag / 3;
            int col = (int)button.Tag % 3;

            if (board[row, col] != '\0')
                return;

            board[row, col] = currentPlayer;
            button.Text = currentPlayer.ToString();
            button.Enabled = false;

            if (CheckWin(currentPlayer))
            {
                MessageBox.Show(this, $"Player {currentPlayer} wins!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                String status, playerName;
                
                    status = "win";
                
                playerName = user;


                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {

                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                InitializeBoard();
                return;
            }

            if (CheckDraw())
            {
                MessageBox.Show("It's a draw!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);

                String status, playerName;
                playerName = user;
                status = "draw";


                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values (@b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {

                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                InitializeBoard();
                return;
            }
            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';

            if (currentPlayer == 'O')
                MakeComputerMove();

        }

        private void button5_Click(object sender, EventArgs e)
        {

            Button button = (Button)sender;

            int row = (int)button.Tag / 3;
            int col = (int)button.Tag % 3;

            if (board[row, col] != '\0')
                return;

            board[row, col] = currentPlayer;
            button.Text = currentPlayer.ToString();
            button.Enabled = false;

            if (CheckWin(currentPlayer))
            {
                MessageBox.Show(this, $"Player {currentPlayer} wins!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                String status, playerName;
               
                    status = "win";
               
                playerName = user;


                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {

                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                InitializeBoard();
                return;
            }

            if (CheckDraw())
            {
                MessageBox.Show("It's a draw!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);

                String status, playerName;
                playerName = user;
                status = "draw";


                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values (@b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {

                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                InitializeBoard();
                return;
            }

            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';

            if (currentPlayer == 'O')
                MakeComputerMove();

        }

        private void button6_Click(object sender, EventArgs e)
        {

            Button button = (Button)sender;

            int row = (int)button.Tag / 3;
            int col = (int)button.Tag % 3;

            if (board[row, col] != '\0')
                return;

            board[row, col] = currentPlayer;
            button.Text = currentPlayer.ToString();
            button.Enabled = false;

            if (CheckWin(currentPlayer))
            {
                MessageBox.Show(this, $"Player {currentPlayer} wins!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                String status, playerName;
                
                    status = "win";
              
                playerName = user;


                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {

                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                InitializeBoard();
                return;
            }

            if (CheckDraw())
            {
                MessageBox.Show("It's a draw!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);

                String status, playerName;
                playerName = user;
                status = "draw";


               try
               {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values (@b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {

                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                InitializeBoard();
                return;
            }
            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';

            if (currentPlayer == 'O')
                MakeComputerMove();

        }

        private void button7_Click(object sender, EventArgs e)
        {

            Button button = (Button)sender;

            int row = (int)button.Tag / 3;
            int col = (int)button.Tag % 3;

            if (board[row, col] != '\0')
                return;

            board[row, col] = currentPlayer;
            button.Text = currentPlayer.ToString();
            button.Enabled = false;

            if (CheckWin(currentPlayer))
            {
                MessageBox.Show(this, $"Player {currentPlayer} wins!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                String status, playerName;
                   status = "win";
               
                playerName = user;


               try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {

                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                InitializeBoard();
                return;
            }

            if (CheckDraw())
            {
                MessageBox.Show("It's a draw!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);

                String status, playerName;
                playerName = user;
                status = "draw";


                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values (@b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {

                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                InitializeBoard();
                return;
            }

            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';

            if (currentPlayer == 'O')
                MakeComputerMove();

        }

        private void button8_Click(object sender, EventArgs e)
        {

            Button button = (Button)sender;

            int row = (int)button.Tag / 3;
            int col = (int)button.Tag % 3;

            if (board[row, col] != '\0')
                return;

            board[row, col] = currentPlayer;
            button.Text = currentPlayer.ToString();
            button.Enabled = false;

            if (CheckWin(currentPlayer))
            {
                MessageBox.Show(this, $"Player {currentPlayer} wins!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                String status, playerName;
                
                    status = "win";
               
                playerName = user;


               try
               {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {

                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                InitializeBoard();
                return;
            }

            if (CheckDraw())
            {
                MessageBox.Show("It's a draw!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);

                String status, playerName;
                playerName = user;
                status = "draw";


                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values (@b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {

                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                InitializeBoard();
                return;
            }

            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';

            if (currentPlayer == 'O')
                MakeComputerMove();

        }

        private void button9_Click(object sender, EventArgs e)
        {

            Button button = (Button)sender;

            int row = (int)button.Tag / 3;
            int col = (int)button.Tag % 3;

            if (board[row, col] != '\0')
                return;

            board[row, col] = currentPlayer;
            button.Text = currentPlayer.ToString();
            button.Enabled = false;
            if (CheckWin(currentPlayer))
            {
                MessageBox.Show(this, $"Player {currentPlayer} wins!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                String status, playerName;
                
                    status = "win";
                
               
                playerName = user;


               try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {

                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                InitializeBoard();
                return;
            }

            if (CheckDraw())
            {
                MessageBox.Show("It's a draw!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);

                String status, playerName;
                playerName = user;
                status = "draw";


               try
               {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values (@b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);



                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
               }
                catch (SqlException ex)
                {

                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                InitializeBoard();
                return;
            }

            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';

            if (currentPlayer == 'O')
                MakeComputerMove();

        }

       
    }

   
}
